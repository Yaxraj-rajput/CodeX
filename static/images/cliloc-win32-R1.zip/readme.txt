You can find the source for this program in the file releases for SteamEngine: http://steamengine.sourceforge.net/
That is also where you would look to find newer versions of this, if there are any.

	This readme refers to "cliloc.*" and "cliloc.*.ini" files. By these, we mean files whose names begin with "cliloc", and which have some extension other than cpp, hpp, map, obj, or exe (which are ignored since they are related to this program). For example, "cliloc.*" refers to "cliloc.enu", "cliloc.kor", and any other files with similar names. One last example: the "cliloc.*.ini" file for "cliloc.enu" is named "cliloc.enu.ini".

To use this, first copy the "cliloc.*" files from your Ultima Online folder into the same folder as "cliloc.exe". Then run "cliloc.exe", and it will output "cliloc.*.ini" files based on the contents of those "cliloc.*" files.

	Each "cliloc.*.ini" files will contain a bunch of entries in this format:
	entryID Text

Now, you can change the "cliloc.*.ini" files and then re-run "cliloc.exe", which will then change the "cliloc.*" files to include your modifications (if any). You will then need to copy the changed "cliloc.*" files into your UO folder if you want to see your modified cliloc entries. If you are running a shard and you want your players to see the changed/new entries, then you will also need to send the modified "cliloc.*" files to your players.

NOTE: This program writes the "cliloc.*" files identically to how they were written originally, and it writes the entire contents of the files every time it is run (except when it is writing a "cliloc.*.ini" file instead.

NOTE: This looks for the "cliloc.*" files to determine what to act on, and so if you delete a "cliloc.*" file but leave its corresponding "cliloc.*.ini" file, this program will NOT write a new "cliloc.*" file for it.

A compile.bat file is included in case you want to recompile this. It is written to use Digital Mars' C++ compiler, which is free (Go to www.digitalmars.com). If you want to compile this on *nix, you'll need to change some parts of the source. But that shouldn't be hard; This is a tiny program.

-SL
Oct 30, 2004